console.info("chrome-ext template-vue-ts content script");
