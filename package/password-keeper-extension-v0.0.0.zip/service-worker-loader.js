import './assets/chunk-f484e48e.js';
