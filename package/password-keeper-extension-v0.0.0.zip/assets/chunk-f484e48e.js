console.info("chrome-ext template-vue-ts background script");
