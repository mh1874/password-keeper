(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/chunk-bf4986ff.js")
    );
  })().catch(console.error);

})();
